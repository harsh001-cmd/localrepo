document.addEventListener('DOMContentLoaded', () => {
            // --- DATA ---
            const products = [
                { id: 1, name: 'Anime Hero Poster', category: 'Anime', img: 'https://placehold.co/600x800/6366f1/ffffff?text=Anime+Hero' },
                { id: 2, name: 'Supercar Dreams', category: 'Cars', img: 'https://placehold.co/600x800/ef4444/ffffff?text=Supercar' },
                { id: 3, name: 'Cricket Legend', category: 'Cricketers', img: 'https://placehold.co/600x800/22c55e/ffffff?text=Cricket' },
                { id: 4, name: 'Football Goal', category: 'Footballers', img: 'https://placehold.co/600x800/14b8a6/ffffff?text=Football' },
                { id: 5, name: 'Samurai Spirit', category: 'Samurai', img: 'https://placehold.co/600x800/f97316/ffffff?text=Samurai' },
                { id: 6, name: 'F1 Racing Car', category: 'F1 Cars', img: 'https://placehold.co/600x800/ec4899/ffffff?text=F1+Car' },
                { id: 7, name: 'Off-Road Adventure', category: 'Off-Roading', img: 'https://placehold.co/600x800/84cc16/ffffff?text=Off-Road' },
                { id: 8, name: 'Stay Motivated', category: 'Motivational', img: 'https://placehold.co/600x800/a855f7/ffffff?text=Motivation' },
                { id: 9, name: 'Enchanted Forest', category: 'Forest', img: 'https://placehold.co/600x800/10b981/ffffff?text=Forest' },
                { id: 10, name: 'Abstract Decor Art', category: 'Decor', img: 'https://placehold.co/600x800/f59e0b/ffffff?text=Decor' },
                { id: 11, name: 'Football Club Crest', category: 'Franchise Teams', img: 'https://placehold.co/600x800/0ea5e9/ffffff?text=Football+Team' },
                { id: 12, name: 'Cricket Team Logo', category: 'Franchise Teams', img: 'https://placehold.co/600x800/d946ef/ffffff?text=Cricket+Team' },
            ];

            const pricing = {
                poster: { 'A4': 95, 'A3': 110, 'A2': 199, 'A1': 299 },
                singleFrame: { 'A4': 399, 'A3': 499, 'A2': 799, 'A1': 1299 },
                combo2: { 'A4': 699, 'A3': 899, 'A2': 1399, 'A1': 2299 },
                combo3: { 'A4': 899, 'A3': 1099, 'A2': 1799, 'A1': 2999 }
            };

            let cart = [];

            // --- DOM ELEMENTS ---
            const productGrid = document.getElementById('product-grid');
            const categoryFiltersContainer = document.getElementById('category-filters');
            const modal = document.getElementById('product-modal');
            const cartButton = document.getElementById('cart-button');
            const cartPanel = document.getElementById('cart-panel');
            const closeCartButton = document.getElementById('close-cart-button');
            const cartCount = document.getElementById('cart-count');
            const cartItemsContainer = document.getElementById('cart-items');
            const cartSubtotalEl = document.getElementById('cart-subtotal');
            const cartDiscountEl = document.getElementById('cart-discount');
            const cartTotalEl = document.getElementById('cart-total');

            // --- FUNCTIONS ---

            // Render Products on the page
            const renderProducts = (filter = 'All') => {
                productGrid.innerHTML = '';
                const filteredProducts = filter === 'All' ? products : products.filter(p => p.category === filter);

                filteredProducts.forEach(product => {
                    const card = document.createElement('div');
                    card.className = 'product-card bg-white rounded-lg shadow-sm overflow-hidden cursor-pointer';
                    card.innerHTML = `
                        <img src="${product.img}" alt="${product.name}" class="w-full h-80 object-cover">
                        <div class="p-4">
                            <h3 class="font-semibold text-lg text-slate-800">${product.name}</h3>
                            <p class="text-sm text-slate-500">${product.category}</p>
                        </div>
                    `;
                    card.addEventListener('click', () => openProductModal(product.id));
                    productGrid.appendChild(card);
                });
            };
            
            // Render Category Filters
            const renderCategories = () => {
                const categories = ['All', ...new Set(products.map(p => p.category))];
                categoryFiltersContainer.innerHTML = '';
                categories.forEach(category => {
                    const button = document.createElement('button');
                    button.textContent = category;
                    button.className = 'category-btn px-4 py-2 text-sm font-medium border rounded-full hover:bg-blue-500 hover:text-white transition-colors';
                    if (category === 'All') {
                        button.classList.add('active');
                    }
                    button.dataset.category = category;
                    categoryFiltersContainer.appendChild(button);
                });
            };
            
            // Handle Category Filter Clicks
            categoryFiltersContainer.addEventListener('click', (e) => {
                if(e.target.tagName === 'BUTTON') {
                    document.querySelectorAll('.category-btn').forEach(btn => btn.classList.remove('active'));
                    e.target.classList.add('active');
                    renderProducts(e.target.dataset.category);
                }
            });

            // Open Product Modal
            const openProductModal = (productId) => {
                const product = products.find(p => p.id === productId);
                modal.classList.add('active');
                modal.querySelector('.modal-content').innerHTML = `
                    <div class="w-full md:w-1/2">
                        <img src="${product.img}" alt="${product.name}" class="w-full h-full object-cover">
                    </div>
                    <div class="w-full md:w-1/2 p-6 overflow-y-auto">
                        <div class="flex justify-between items-start mb-4">
                            <h2 class="text-3xl font-bold text-slate-800">${product.name}</h2>
                            <button class="text-slate-500 hover:text-red-500 text-3xl" onclick="closeProductModal()">&times;</button>
                        </div>
                        <p class="text-slate-600 mb-6">${product.category}</p>
                        
                        <div id="product-options" data-product-id="${product.id}">
                            <!-- Framing Options -->
                            <div class="mb-6">
                                <h4 class="font-semibold mb-2 text-slate-700">1. Select Style</h4>
                                <div class="grid grid-cols-2 gap-2">
                                    ${createRadioOption('frame', 'poster', 'Poster Only', true)}
                                    ${createRadioOption('frame', 'singleFrame', 'With Frame')}
                                    ${createRadioOption('frame', 'combo2', 'Combo of 2 (Framed)')}
                                    ${createRadioOption('frame', 'combo3', 'Set of 3 (Framed)')}
                                </div>
                            </div>

                            <!-- Size Options -->
                            <div class="mb-6">
                                <h4 class="font-semibold mb-2 text-slate-700">2. Select Size</h4>
                                <div class="grid grid-cols-2 gap-2">
                                    ${createRadioOption('size', 'A4', 'A4 Size', true)}
                                    ${createRadioOption('size', 'A3', 'A3 Size')}
                                    ${createRadioOption('size', 'A2', 'A2 Size')}
                                    ${createRadioOption('size', 'A1', 'A1 Size')}
                                </div>
                            </div>
                        </div>

                        <!-- Price & Add to Cart -->
                        <div class="mt-8 flex items-center justify-between">
                             <p class="text-3xl font-bold text-blue-600" id="modal-price">₹${pricing.poster.A4}</p>
                            <button id="add-to-cart-btn" class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-lg transition-colors flex items-center gap-2">
                               <i class="fas fa-cart-plus"></i> Add to Cart
                            </button>
                        </div>
                    </div>
                `;

                // Add event listeners for options
                const optionsForm = modal.querySelector('#product-options');
                optionsForm.addEventListener('change', updateModalPrice);
                modal.querySelector('#add-to-cart-btn').addEventListener('click', addToCart);
            };
            
            // Helper to create radio buttons
            const createRadioOption = (name, value, label, checked = false) => `
                <label class="block border rounded-lg p-3 text-center cursor-pointer has-[:checked]:bg-blue-100 has-[:checked]:border-blue-500 has-[:checked]:ring-2 has-[:checked]:ring-blue-300">
                    <input type="radio" name="${name}" value="${value}" class="sr-only" ${checked ? 'checked' : ''}>
                    <span class="text-sm font-medium text-slate-700">${label}</span>
                </label>
            `;

            // Update price in modal based on selection
            const updateModalPrice = () => {
                const selectedFrame = document.querySelector('input[name="frame"]:checked').value;
                const selectedSize = document.querySelector('input[name="size"]:checked').value;
                const price = pricing[selectedFrame][selectedSize];
                document.getElementById('modal-price').textContent = `₹${price}`;
            };

            // Close Product Modal
            window.closeProductModal = () => {
                modal.classList.remove('active');
            };

            // Add to Cart Logic
            const addToCart = () => {
                const productId = parseInt(document.querySelector('#product-options').dataset.productId);
                const product = products.find(p => p.id === productId);
                const selectedFrame = document.querySelector('input[name="frame"]:checked').value;
                const selectedSize = document.querySelector('input[name="size"]:checked').value;
                const price = pricing[selectedFrame][selectedSize];

                // Create a unique ID for the cart item based on its properties
                const cartItemId = `${productId}-${selectedSize}-${selectedFrame}`;

                const existingItem = cart.find(item => item.id === cartItemId);

                if (existingItem) {
                    existingItem.quantity++;
                } else {
                    cart.push({
                        id: cartItemId,
                        productId: productId,
                        name: product.name,
                        img: product.img,
                        frameType: selectedFrame,
                        size: selectedSize,
                        price: price,
                        isPosterOnly: selectedFrame === 'poster',
                        quantity: 1
                    });
                }
                updateCart();
                closeProductModal();
                showToast(`${product.name} added to cart!`);
            };

            // Update everything related to cart
            const updateCart = () => {
                renderCartItems();
                updateCartTotals();
                updateCartCount();
            };

            // Render items in cart panel
            const renderCartItems = () => {
                if (cart.length === 0) {
                    cartItemsContainer.innerHTML = `<p class="text-slate-500 text-center mt-8">Your cart is empty.</p>`;
                    return;
                }
                cartItemsContainer.innerHTML = cart.map(item => `
                    <div class="flex items-start gap-4 mb-4" data-cart-id="${item.id}">
                        <img src="${item.img}" class="w-20 h-24 object-cover rounded-md">
                        <div class="flex-grow">
                            <p class="font-semibold text-slate-800">${item.name}</p>
                            <p class="text-sm text-slate-500">${item.size} / ${getFrameLabel(item.frameType)}</p>
                            <p class="font-bold text-slate-800 mt-1">₹${item.price.toFixed(2)}</p>
                             <div class="flex items-center gap-2 mt-2">
                                <button class="quantity-change bg-slate-200 rounded-full w-6 h-6" data-change="-1">-</button>
                                <span>${item.quantity}</span>
                                <button class="quantity-change bg-slate-200 rounded-full w-6 h-6" data-change="1">+</button>
                            </div>
                        </div>
                        <button class="remove-from-cart text-slate-400 hover:text-red-500 text-lg">&times;</button>
                    </div>
                `).join('');
            };
            
            // Handle Cart Item Interactions (Remove/Quantity)
            cartItemsContainer.addEventListener('click', e => {
                const cartItemDiv = e.target.closest('[data-cart-id]');
                if (!cartItemDiv) return;
                const cartId = cartItemDiv.dataset.cartId;

                if (e.target.classList.contains('remove-from-cart')) {
                    cart = cart.filter(item => item.id !== cartId);
                    updateCart();
                }
                if (e.target.classList.contains('quantity-change')) {
                    const change = parseInt(e.target.dataset.change);
                    const item = cart.find(i => i.id === cartId);
                    if (item) {
                        item.quantity += change;
                        if (item.quantity <= 0) {
                             cart = cart.filter(i => i.id !== cartId);
                        }
                        updateCart();
                    }
                }
            });

            // Calculate cart totals and apply discounts
            const updateCartTotals = () => {
                const subtotal = cart.reduce((acc, item) => acc + (item.price * item.quantity), 0);
                
                // --- Discount Logic for Posters ---
                let posterItems = cart.filter(item => item.isPosterOnly)
                                      .flatMap(item => Array(item.quantity).fill(item)) // Expand by quantity
                                      .sort((a, b) => a.price - b.price); // Sort by price to discount cheapest first
                
                let totalPosters = posterItems.length;
                let freePosters = 0;
                if (totalPosters >= 10) freePosters = 4;
                else if (totalPosters >= 5) freePosters = 2;
                else if (totalPosters >= 3) freePosters = 1;

                let discount = 0;
                if (freePosters > 0) {
                    discount = posterItems.slice(0, freePosters).reduce((acc, item) => acc + item.price, 0);
                }

                const total = subtotal - discount;

                cartSubtotalEl.textContent = `₹${subtotal.toFixed(2)}`;
                cartDiscountEl.textContent = `- ₹${discount.toFixed(2)}`;
                cartTotalEl.textContent = `₹${total.toFixed(2)}`;
            };

            // Update cart bubble count
            const updateCartCount = () => {
                const totalItems = cart.reduce((acc, item) => acc + item.quantity, 0);
                cartCount.textContent = totalItems;
            };
            
            const getFrameLabel = (frameType) => {
                const labels = {
                    poster: 'Poster Only',
                    singleFrame: 'With Frame',
                    combo2: 'Combo of 2',
                    combo3: 'Set of 3'
                };
                return labels[frameType] || '';
            };
            
            const showToast = (message) => {
                const toast = document.createElement('div');
                toast.textContent = message;
                toast.className = 'fixed bottom-5 right-5 bg-green-500 text-white py-2 px-4 rounded-lg shadow-lg animate-bounce';
                document.body.appendChild(toast);
                setTimeout(() => {
                    toast.remove();
                }, 3000);
            };

            // --- EVENT LISTENERS ---
            cartButton.addEventListener('click', () => cartPanel.classList.add('open'));
            closeCartButton.addEventListener('click', () => cartPanel.classList.remove('open'));
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    closeProductModal();
                }
            });


            // --- INITIALIZATION ---
            renderCategories();
            renderProducts();
        });