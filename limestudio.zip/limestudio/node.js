// --- Advanced Backend Server using Node.js and Express.js ---
// This server includes mock payment processing, tracking, and analytics.

// 1. Import necessary libraries
const express = require('express');
const cors = require('cors');
const mongodb = require('mongoose')
// In a real app, you would install and import the Stripe library
// const stripe = require('stripe')('YOUR_STRIPE_SECRET_KEY');

const app = express();
const PORT = 3000;

// 2. Apply Middleware
app.use(cors()); // Allows cross-origin requests
app.use(express.json()); // Allows the server to understand JSON
app.use(express.urlencoded({ extended: true }));

// --- MOCK DATABASE & ANALYTICS STORAGE ---
// In a real-world application, all of this data would be stored in a persistent
// database like MongoDB, PostgreSQL, or Firebase Firestore.

const db = {
    products: [
        { id: 1, name: 'Anime Hero Poster', category: 'Anime', img: 'https://placehold.co/600x800/6366f1/ffffff?text=Anime+Hero' },
        { id: 2, name: 'Supercar Dreams', category: 'Cars', img: 'https://placehold.co/600x800/ef4444/ffffff?text=Supercar' },
        { id: 3, name: 'Cricket Legend', category: 'Cricketers', img: 'https://placehold.co/600x800/22c55e/ffffff?text=Cricket' },
        { id: 4, name: 'Football Goal', category: 'Footballers', img: 'https://placehold.co/600x800/14b8a6/ffffff?text=Football' },
        { id: 5, name: 'Samurai Spirit', category: 'Samurai', img: 'https://placehold.co/600x800/f97316/ffffff?text=Samurai' },
        // ... more products
    ],
    pricing: {
        poster: { 'A4': 95, 'A3': 110, 'A2': 199, 'A1': 299 },
        singleFrame: { 'A4': 399, 'A3': 499, 'A2': 799, 'A1': 1299 },
        combo2: { 'A4': 699, 'A3': 899, 'A2': 1399, 'A1': 2299 },
        combo3: { 'A4': 899, 'A3': 1099, 'A2': 1799, 'A1': 2999 }
    },
    // Analytics Data
    tracking: {
        visitors: [], // Store visitor timestamps and info
        addToCartEvents: [], // Store products added to cart
        orders: [] // Store completed orders
    }
};

// --- API ROUTES / ENDPOINTS ---

// == PRODUCT & PRICING ROUTES ==
app.get('/api/products', (req, res) => {
    res.send(db.products);
});

app.get('/api/pricing', (req, res) => {
    res.send(db.pricing);
});


// == PAYMENT PROCESSING ROUTE ==
// This endpoint simulates creating a payment session with a provider like Stripe.
app.post('/api/create-payment-intent', async (req, res) => {
    const { totalAmount } = req.body; // Frontend sends the final cart total

    // The amount should be in the smallest currency unit (e.g., paise for INR)
    const amountInPaise = Math.round(totalAmount * 100);

    console.log(`Creating payment intent for ₹${totalAmount} (${amountInPaise} paise)`);

    // --- Real Stripe Integration Would Look Like This ---
    /*
    try {
        const paymentIntent = await stripe.paymentIntents.create({
            amount: amountInPaise,
            currency: 'inr',
            payment_method_types: [
                'card',
                'upi',
                // Stripe automatically enables Google Pay, PhonePe etc. via UPI
            ],
        });

        // Send the client secret back to the frontend
        res.json({ clientSecret: paymentIntent.client_secret });

    } catch (error) {
        console.error("Stripe Error:", error);
        res.status(500).json({ error: 'Failed to create payment intent.' });
    }
    */

    // --- Mock Response for this Example ---
    // We send back a fake "client secret" for the frontend to simulate the next step.
    res.json({
        clientSecret: `pi_${Date.now()}_secret_${Math.random().toString(36).substring(2)}`
    });
});


// == TRACKING & ANALYTICS ROUTES ==

// Log a new visitor to the site
app.post('/api/track/visitor', (req, res) => {
    const { country, city, userAgent } = req.body; // Frontend could send this info
    const visitorData = {
        timestamp: new Date().toISOString(),
        country: country || 'Unknown',
        city: city || 'Unknown',
        userAgent: userAgent,
    };
    db.tracking.visitors.push(visitorData);
    console.log('New visitor logged:', visitorData.country);
    res.status(200).json({ message: 'Visitor tracked.' });
});

// Log an "add to cart" event
app.post('/api/track/add-to-cart', (req, res) => {
    const { productId, productName, price } = req.body;
    const cartEvent = {
        timestamp: new Date().toISOString(),
        productId,
        productName,
        price
    };
    db.tracking.addToCartEvents.push(cartEvent);
    console.log(`'${productName}' added to cart.`);
    res.status(200).json({ message: 'Add to cart event tracked.' });
});


// == ORDER PROCESSING ROUTE ==
app.post('/api/orders', (req, res) => {
    const { cart, totalAmount, paymentIntentId, customerDetails } = req.body;

    // In a real app, you would first verify the paymentIntentId with Stripe
    // to confirm the payment was successful before saving the order.

    const newOrder = {
        orderId: `order_${Date.now()}`,
        timestamp: new Date().toISOString(),
        items: cart,
        totalAmount,
        paymentIntentId, // For reference
        customer: customerDetails,
        status: 'Processing' // Initial order status
    };
    db.tracking.orders.push(newOrder);
    console.log('New order received and saved:', newOrder.orderId);
    res.status(201).json({ message: 'Order created successfully!', order: newOrder });
});


// == ADMIN ANALYTICS DATA ROUTE ==
// This endpoint provides a summary of all tracked data.
app.get('/api/analytics/summary', (req, res) => {
    const summary = {
        totalVisitors: db.tracking.visitors.length,
        totalAddToCartEvents: db.tracking.addToCartEvents.length,
        totalOrders: db.tracking.orders.length,
        totalRevenue: db.tracking.orders.reduce((sum, order) => sum + order.totalAmount, 0),
        // You could add much more detail here, like visitors by country
        visitorsByCountry: db.tracking.visitors.reduce((acc, visitor) => {
            acc[visitor.country] = (acc[visitor.country] || 0) + 1;
            return acc;
        }, {})
    };
    res.json(summary);
});


// 4. Start the Server
app.listen(PORT, () => {
    console.log(`Advanced server is running on http://localhost:${PORT}`);
});